//
//  ViewController.swift
//  Compass
//
//  Created by Joseph Zoland on 3/19/17.
//  Copyright © 2017 Joseph Zoland. All rights reserved.
//

import UIKit

class StartViewController: UIViewController {
    
    var destination = ""
    let destdict = [0: "North", 1: "East", 2: "South", 3: "West"]
    
    @IBAction func compassButtonPressed(_ sender: UIButton) {
        destination = destdict[sender.tag]!
        print (destination)
    }
    
    @IBAction func myUnwindAction(unwindSegue: UIStoryboardSegue) {
        //Put this code in controller you want to unwind to (i.e., the one early in the chain)
        //Afterwards, in controller you want to unwind from, ctrl-drag your button to "exit" button at top of controller
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        let navigationController = segue.destination as! UINavigationController
        let DestinationViewController = navigationController.topViewController as! DestinationViewController
        DestinationViewController.destination = destination

    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

