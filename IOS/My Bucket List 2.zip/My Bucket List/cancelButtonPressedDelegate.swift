//
//  cancelButtonPressedDelegate.swift
//  My Bucket List
//
//  Created by Joseph Zoland on 3/18/17.
//  Copyright © 2017 Joseph Zoland. All rights reserved.
//

import Foundation
import UIKit

protocol cancelButtonPressedDelegate: class {
    func cancelButtonPressed(by controller: UIViewController)
    func addText(by controller:UIViewController, with text: String)
    func saveButtonPressedWithEdit(controller: UIViewController, text: String, index: Int)
}
