//
//  ViewController.swift
//  My Bucket List
//
//  Created by Joseph Zoland on 3/18/17.
//  Copyright © 2017 Joseph Zoland. All rights reserved.
//

import UIKit

class OpeningViewController: UIViewController, cancelButtonPressedDelegate {
    
    func cancelButtonPressed(by controller: UIViewController) {
        dismiss(animated: true, completion: nil)
    }
    
    func addText(by controller:UIViewController, with text: String) {
    }
    func saveButtonPressedWithEdit(controller: UIViewController, text: String, index: Int) {
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //For the purposes of this example, BucketListTableViewController is the outer/later view, sending the action
        
//        if segue.identifier == "addItem" {
            let navigationController = segue.destination as! UINavigationController
            let BucketListTableViewController = navigationController.topViewController as! BucketListTableViewController
            BucketListTableViewController.delegate = self
//        }
    }
}

