//
//  BucketListTableViewController.swift
//  My Bucket List
//
//  Created by Joseph Zoland on 3/18/17.
//  Copyright © 2017 Joseph Zoland. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class BucketListTableViewController: UITableViewController, cancelButtonPressedDelegate {
    
    weak var delegate: cancelButtonPressedDelegate?
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var tasklist = [BucketListItem]()

    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
        delegate?.cancelButtonPressed(by: self)
    }
    
    func fetchAllItems() {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "BucketListItem")
        do {
            let result = try managedObjectContext.fetch(request)
            tasklist = result as! [BucketListItem]
        } catch {
            print("\(error)")
        }
        
        
    }
    
    func cancelButtonPressed(by controller: UIViewController) {
        dismiss(animated: true, completion: nil)
    }
    
    func addText(by controller:UIViewController, with text: String) {
        print ("reaching create")
        let item = NSEntityDescription.insertNewObject(forEntityName: "BucketListItem", into: managedObjectContext) as! BucketListItem
        item.text = text
        tasklist.append(item)
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
    }
    
    func saveButtonPressedWithEdit(controller: UIViewController, text: String, index: Int) {
        print ("reaching edit")
        print ("tasklist[index].text is \(tasklist[index].text)")
        print ("text is \(text)")
        tasklist[index].text = text
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchAllItems()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        //This code passes the index path for the tapped row through the segue route, "edit", in this example
        //This can then be used in tandem with "Prepare for segue" snippet to pass indexPath to next controller
        performSegue(withIdentifier: "edit", sender: indexPath)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //For the purposes of this example, BucketListTableViewController is the outer/later view, sending the action
        
        let navigationController = segue.destination as! UINavigationController
        let AddItemViewController = navigationController.topViewController as! AddItemViewController
        AddItemViewController.delegate = self
        
        //typeof does not differentiate between both types of senders
        print ("typeof sender is \(type(of:sender))")
        
        //this does differentiate, but don't know how to make it a conditional in code format
        print ("sender is \(sender)")

        if segue.identifier == "edit" {
//        if type(of: unwrappedsender) == Any?() {
            let indexPath = sender as! IndexPath
            AddItemViewController.indexOfItemToEdit = indexPath.row
            AddItemViewController.textOfItemToEdit = tasklist[indexPath.row].text!
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //    return the number of rows you want to iterate through, typically from an array.count (example below)
        return tasklist.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //    typical syntax below:
        let cell = tableView.dequeueReusableCell(withIdentifier: "BucketListItem", for: indexPath)
        cell.textLabel?.text = tasklist[indexPath.row].text!
        return cell
    }
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt
        indexPath: IndexPath) {
        //Note: In this example, tasklist is the list of items in the table
        let task = tasklist[indexPath.row]
        managedObjectContext.delete(task)
        
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        
        tasklist.remove(at: indexPath.row)
        tableView.reloadData()
    }

}
