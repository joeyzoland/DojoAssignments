//
//  AddItemViewController.swift
//  My Bucket List
//
//  Created by Joseph Zoland on 3/18/17.
//  Copyright © 2017 Joseph Zoland. All rights reserved.
//

import Foundation
import UIKit

class AddItemViewController: UIViewController {
    
    weak var delegate: cancelButtonPressedDelegate?
    
    var indexOfItemToEdit: Int?
    var textOfItemToEdit: String?
    
    @IBOutlet weak var newTask: UITextField!
    
    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
        delegate?.cancelButtonPressed(by: self)
    }
    
    @IBAction func saveButtonPressed(_ sender: UIBarButtonItem) {
        if newTask.text == "" {
            delegate?.addText(by: self, with: newTask.text!)
        }
        else if textOfItemToEdit != nil {
            delegate?.saveButtonPressedWithEdit(controller: self, text: newTask.text!, index: indexOfItemToEdit!)
        }
        else {
            delegate?.cancelButtonPressed(by: self)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        print ("indexOfItemToEdit is \(indexOfItemToEdit)")
//        print ("textOfItemToEdit is \(textOfItemToEdit)")
        newTask.text = textOfItemToEdit
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
