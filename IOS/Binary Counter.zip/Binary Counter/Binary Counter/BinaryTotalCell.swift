//
//  BinaryTotalCell.swift
//  Binary Counter
//
//  Created by Joseph Zoland on 3/21/17.
//  Copyright © 2017 Joseph Zoland. All rights reserved.
//

import Foundation
import UIKit

class BinaryTotalCell: UITableViewCell {
    
    @IBOutlet weak var totalLabel: UILabel!
    
}
