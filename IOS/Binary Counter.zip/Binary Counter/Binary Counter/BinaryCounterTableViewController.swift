//
//  ViewController.swift
//  Binary Counter
//
//  Created by Joseph Zoland on 3/20/17.
//  Copyright © 2017 Joseph Zoland. All rights reserved.
//

import UIKit

class BinaryCounterTableViewController: UITableViewController, addDelegateController {
    
    var numArray: [Int] = [Int]()
    
    var total = 0
    var counter = 0
    @IBOutlet weak var totalLabel: UILabel!
    
    func retrieveValue(sender: BinaryCounterCell) -> Int {
        return Int(sender.incrementLabel.text!)!
    }
    
    func increment(number: Int) {
        let cell = (tableView.cellForRow(at: [0, 16])) as! BinaryTotalCell
        cell.totalLabel!.text = String(Int(cell.totalLabel!.text!)! + number)
        print ("cell.totalLabel!.text is \(cell.totalLabel!.text)")
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //    return the number of rows you want to iterate through, typically from an array.count (example below)
        return numArray.count + 1
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //    typical syntax below:
        if counter < numArray.count {
            let cell = tableView.dequeueReusableCell(withIdentifier: "BinaryCounter") as! BinaryCounterCell
            let number = numArray[indexPath.row]
            cell.incrementLabel.text = String(number)
            cell.delegate = self
            counter += 1
            return cell
        }
        else {
            let newCell = tableView.dequeueReusableCell(withIdentifier: "BinaryTotal") as! BinaryTotalCell
            return newCell
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        //Note that pow is a function that takes in doubles and outputs a double, hence the type conversions
        for i in 0 ... 15 {
            numArray.append(Int(pow(10.0, Double(i))))
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

