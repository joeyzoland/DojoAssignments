//
//  BinaryCounterCell.swift
//  Binary Counter
//
//  Created by Joseph Zoland on 3/20/17.
//  Copyright © 2017 Joseph Zoland. All rights reserved.
//

import UIKit

class BinaryCounterCell: UITableViewCell {
    
    weak var delegate: addDelegateController?
    
    @IBOutlet weak var plusButton: UIButton!
    @IBOutlet weak var minusButton: UIButton!
    
    @IBAction func minusButtonPressed(_ sender: UIButton) {
        delegate?.increment(number: -1 * Int(incrementLabel.text!)!)
//        print ("incrementLabel.text is \(incrementLabel.text!)")
//        delegate?.total -= Int(incrementLabel.text!)!
//        print (delegate?.total)
    }
    
    @IBAction func plusButtonPressed(_ sender: UIButton) {
        delegate?.increment(number: Int(incrementLabel.text!)!)
//        print ("incrementLabel.text is \(incrementLabel.text!)")
//        delegate?.total += Int(incrementLabel.text!)!
//        print (delegate?.total)
    }
    
    @IBOutlet weak var incrementLabel: UILabel!
    
}
