//
//  BucketListTableViewController.swift
//  My Bucket List
//
//  Created by Joseph Zoland on 3/18/17.
//  Copyright © 2017 Joseph Zoland. All rights reserved.
//

import Foundation
import UIKit

class BucketListTableViewController: UITableViewController, cancelButtonPressedDelegate {
    
    weak var delegate: cancelButtonPressedDelegate?
    
    var tasklist = ["mastering IOS", "finding a great job"]

    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
        delegate?.cancelButtonPressed(by: self)
    }
    
    func cancelButtonPressed(by controller: UIViewController) {
        dismiss(animated: true, completion: nil)
    }
    
    func addText(by controller:UIViewController, with text: String) {
        tasklist.append(text)
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    
    func saveButtonPressedWithEdit(controller: UIViewController, text: String, index: Int) {
        tasklist[index] = text
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        //This code passes the index path for the tapped row through the segue route, "edit", in this example
        //This can then be used in tandem with "Prepare for segue" snippet to pass indexPath to next controller
        performSegue(withIdentifier: "edit", sender: indexPath)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //For the purposes of this example, BucketListTableViewController is the outer/later view, sending the action
        
        let navigationController = segue.destination as! UINavigationController
        let AddItemViewController = navigationController.topViewController as! AddItemViewController
        AddItemViewController.delegate = self
        
        if segue.identifier == "edit" {
            let indexPath = sender as! IndexPath
            AddItemViewController.indexOfItemToEdit = indexPath.row
            AddItemViewController.textOfItemToEdit = tasklist[indexPath.row]
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //    return the number of rows you want to iterate through, typically from an array.count (example below)
        return tasklist.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //    typical syntax below:
        let cell = tableView.dequeueReusableCell(withIdentifier: "BucketListItem", for: indexPath)
        cell.textLabel?.text = tasklist[indexPath.row]
        return cell
    }
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt
        indexPath: IndexPath) {
        //Note: In this example, tasklist is the list of items in the table
        tasklist.remove(at: indexPath.row)
        tableView.reloadData()
    }

}
