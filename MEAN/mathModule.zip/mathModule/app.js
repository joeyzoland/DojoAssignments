var my_module = require("./mathlib")();
console.log(my_module.add(1, 2))
console.log(my_module.multiply(3, 6))
console.log(my_module.square(3))
console.log(my_module.random(5, 6))
