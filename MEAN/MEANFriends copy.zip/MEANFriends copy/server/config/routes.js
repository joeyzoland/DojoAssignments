console.log("future routes")

module.exports = function(app){
  // app.config(function($routeProvier) {
  //   $routeProvider
  //     .when("/index", {
  //       templateURL: "/partials/index.html"
  //     })
  // })
}
